const swaggerDocument = {
    openapi: "3.0.0",
    info: {
        title: "API de Personagens",
        version: "1.0.0",
        description: "API didática com filtros, ordenação e paginação."
    },
    servers: [
        { url: "http://localhost:3000" }
    ],
    paths: {
        "/api/personagens": {
            get: {
                summary: "Lista personagens com filtros e paginação",
                parameters: [
                    {
                        name: "nome", in: "query",
                        description: "Busca parcial, sem diferenciar maiúsculas.",
                        schema: { type: "string" },
                        example: "nar"
                    },
                    {
                        name: "tipo", in: "query",
                        description: "Tipo exato do personagem.",
                        schema: { type: "string" },
                        example: "Ninja"
                    },
                    {
                        name: "nivelMinimo", in: "query",
                        schema: { type: "number", minimum: 0 },
                        example: 7
                    },
                    {
                        name: "ordenarPor", in: "query",
                        schema: { type: "string", enum: ["nome", "nivel"], default: "nome" }
                    },
                    {
                        name: "ordem", in: "query",
                        schema: { type: "string", enum: ["asc", "desc"], default: "asc" }
                    },
                    {
                        name: "page", in: "query",
                        schema: { type: "integer", minimum: 1, default: 1 }
                    },
                    {
                        name: "limit", in: "query",
                        schema: { type: "integer", minimum: 1, maximum: 50, default: 5 }
                    }
                ],
                responses: {
                    "200": {
                        description: "Lista retornada com sucesso.",
                        content: {
                            "application/json": {
                                example: {
                                    dados: [
                                        { id: 1, nome: "Naruto", tipo: "Ninja", nivel: 9 }
                                    ],
                                    paginacao: {
                                        total: 1, pagina: 1, limite: 5, totalPaginas: 1
                                    }
                                }
                            }
                        }
                    },
                    "400": {
                        description: "Parâmetros inválidos.",
                        content: {
                            "application/json": {
                                example: {
                                    erro: "Parâmetros inválidos. Confira nível, página, limite, ordenação e ordem."
                                }
                            }
                        }
                    }
                }
            }
        }
    }
};
module.exports = swaggerDocument;