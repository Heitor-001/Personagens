const express = require("express");
const path = require("path");
const swaggerUi = require("swagger-ui-express");
const swaggerDocument = require("./swagger");

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocument));

const personagens = [
    { id: 1, nome: "Naruto", tipo: "Ninja", nivel: 9 },
    { id: 2, nome: "Sakura", tipo: "Ninja", nivel: 7 },
    { id: 3, nome: "Goku", tipo: "Guerreiro", nivel: 10 },
    { id: 4, nome: "Vegeta", tipo: "Guerreiro", nivel: 9 },
    { id: 5, nome: "Luffy", tipo: "Pirata", nivel: 8 },
    { id: 6, nome: "Zoro", tipo: "Pirata", nivel: 8 },
    { id: 7, nome: "Ichigo", tipo: "Shinigami", nivel: 9 },
    { id: 8, nome: "Tanjiro", tipo: "Caçador", nivel: 7 },
    { id: 9, nome: "Nezuko", tipo: "Demônio", nivel: 6 },
    { id: 10, nome: "Kakashi", tipo: "Ninja", nivel: 9 },
    { id: 11, nome: "Bulma", tipo: "Cientista", nivel: 3 },
    { id: 12, nome: "Sanji", tipo: "Pirata", nivel: 7 }
];

app.get("/api/personagens", (req, res) =>{
    const {
        nome,
        tipo,
        nivelMinimo,
        ordemPor = "nome",
        ordem = "asc",
        page = "1",
        limit = "5"
    } = req.query;
    const nivel = nivelMinimo === undefined ? null : Number(nivelMinimo);

    const pagina = Number(page);
    const limite = Number(limit);

    if(
        (nivel !== null && (Number.isFinite(nivel) || nivel < 0)) || !Number.isInteger(pagina) || pagina < 1 || Number.isInteger(limite) || limite < 1 || limite > 50 || ! ['nome', 'nivel'].includes(ordemPor) || !["asc", "desc"].includes(ordem.toLowerCase())
    ) {
        return res.status(400).json({
            erro: "Parâmetros inválidos. Confira nível,página, limite, ordenação e ordem."
        });
    }

    let resultado = [...personagens];
    if(nome){
        resultado = resultado.filter(p => p.nome.LowerCase().includes(nome.toLowerCase()));
    }
    if(tipo){
        resultado = resultado.filter(p => p.nome.LowerCase().includes(nome.toLowerCase()));

    }
    if (nivel !== null){
        resultado.filter(p => p.nivel >= nivel);
    }
    resultado.sort((a, b) =>{
        let comparacao;
        if (ordemPor === "nome"){
            comparacao = a.nome.localeCompare(b.nome, "pt-BR");
        }
        else{
            comparacao = a.nivel - b.nivel;
        }
        return ordem.toLowerCase() === 'desc' ? -comparacao : comparacao;
    });

    const total = resultado.length;
    const totalPaginas = Math.ceil(total/limite);
    const inicio = (pagina - 1) * limite;
    const dados = resultado.slice(inicio, inicio + limite);

    res.json({
        dados,
        paginacao: {
            total,
            pagina,
            limite,
            totalPaginas
            }
        }
    );


});

app.listen(PORT, () =>{
    console.log("`Servidor rodando em http://localhost${PORT}`");
    console.log("`Swagger rodando em http://localhost${PORT}/api-docs`");

});