const campoNome = document.getElementById("nome");
const campoTipo = document.getElementById("tipo");
const campoNivel = document.getElementById("nivelMinimo");
const campoOrdenar = document.getElementById("ordenarPor");
const campoOrdem = document.getElementById("ordem");
const lista = document.getElementById("lista");
const mensagem = document.getElementById("mensagem");
const paginaInfo = document.getElementById("paginaInfo");
const botaoAnterior = document.getElementById("anterior");
const botaoProxima = document.getElementById("proxima");
let paginaAtual = 1;
const limite = 4;
async function carregarPersonagens() {
    const parametros = new URLSearchParams();
    if (campoNome.value.trim()) {
        parametros.set("nome", campoNome.value.trim());
    }
    if (campoTipo.value) {
        parametros.set("tipo", campoTipo.value);
    }
    if (campoNivel.value !== "") {
        parametros.set("nivelMinimo", campoNivel.value);
    }
    parametros.set("ordenarPor", campoOrdenar.value);
    parametros.set("ordem", campoOrdem.value);
    parametros.set("page", paginaAtual);
    parametros.set("limit", limite);
    mensagem.textContent = "Carregando...";
    lista.innerHTML = "";
    try {
        const resposta = await fetch(
            `/api/personagens?${parametros.toString()}`
        );
        const resultado = await resposta.json();
        if (!resposta.ok) {
            throw new Error(resultado.erro || "Não foi possível carregar.");
        }
        mostrarPersonagens(resultado.dados);
        atualizarPaginacao(resultado.paginacao);
        mensagem.textContent =
            `${resultado.paginacao.total} personagem(ns) encontrado(s).`;
    } catch (erro) {
        mensagem.textContent = erro.message;
        paginaInfo.textContent = "Página indisponível";
        botaoAnterior.disabled = true;
        botaoProxima.disabled = true;
    }
}
function mostrarPersonagens(personagens) {
    lista.innerHTML = "";
    if (personagens.length === 0) {
        lista.textContent = "Nenhum personagem encontrado.";
        return;
    }
    personagens.forEach(personagem => {
        const card = document.createElement("article");
        card.className = "personagem";
        const titulo = document.createElement("h2");
        titulo.textContent = personagem.nome;
        const tipo = document.createElement("p");
        tipo.textContent = `Tipo: ${personagem.tipo}`;
        const nivel = document.createElement("p");
        nivel.textContent = `Nível: ${personagem.nivel}`;
        card.append(titulo, tipo, nivel);
        lista.appendChild(card);
    });
}
function atualizarPaginacao(paginacao) {
    paginaInfo.textContent =
        `Página ${paginacao.pagina} de ${paginacao.totalPaginas || 1}`;
    botaoAnterior.disabled = paginacao.pagina <= 1;
    botaoProxima.disabled =
        paginacao.pagina >= paginacao.totalPaginas;
}
document.getElementById("buscar").addEventListener("click", () => {
    paginaAtual = 1;
    carregarPersonagens();
});
document.getElementById("limpar").addEventListener("click", () => {
    campoNome.value = "";
    campoTipo.value = "";
    campoNivel.value = "";
    campoOrdenar.value = "nome";
    campoOrdem.value = "asc";
    paginaAtual = 1;
    carregarPersonagens();
});
botaoAnterior.addEventListener("click", () => {
    if (paginaAtual > 1) {
        paginaAtual--;
        carregarPersonagens();
    }
});
botaoProxima.addEventListener("click", () => {
    paginaAtual++;
    carregarPersonagens();
});
carregarPersonagens();
